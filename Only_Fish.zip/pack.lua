OF = {}

Debug:Print("Loading OnlyFish Bait Menu...")

Pack:Require("Scripts/baitmenu.lua")